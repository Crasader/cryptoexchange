<?php

namespace App\Console\Commands;

use Kevupton\LaravelCoinpayments\Models\Transaction;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Auth;

class TransactionReturns extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'TransactionReturns:transactionreturns';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get the transactions activated after 7 days';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
  
        Transaction::where('confirms_needed', '=', 0)->update(['status_date' => Carbon::now(), 'save_date' => Carbon::now(), 'confirms_needed' => 99]);

        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Premium Plan')->whereRaw('status_date >= SUBDATE( NOW(), INTERVAL 6 DAY)')->where('withdrawn', 'NO')->where('week_count', '<=', 8)->update(['rate' => DB::raw('rate + 0.01488095'), 'returns' =>  DB::raw('rate / 100 * amount_btc + returns')]);
        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Ultimate Plan')->whereRaw('status_date >= SUBDATE( NOW(), INTERVAL 6 DAY)')->where('withdrawn', 'NO')->where('week_count', '<=', 8)->update(['rate' => DB::raw('rate + 0.02232143'), 'returns' =>  DB::raw('rate / 100 * amount_btc + returns')]);


        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Premium Plan')->where('status_date' ,'<=' , Carbon::now()->subDays(7))->where('withdrawn', 'NO')->where('week_count', '<=', 8)->update(['rate' => DB::raw('0.1 + rate1'), 'rate1' => DB::raw('rate'), 'product' => DB::raw('rate * amount_btc'), 'returns' =>  DB::raw('product + bal_after_7days'), 'save_date' => DB::raw('status_date'),  'week_count' => DB::raw('week_count + 1'), 'status_date' => Carbon::now()]);
        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Ultimate Plan')->where('status_date' ,'<=' , Carbon::now()->subDays(7))->where('withdrawn', 'NO')->where('week_count', '<=', 8)->update(['rate' => DB::raw('0.15 + rate1'), 'rate1' => DB::raw('rate'), 'product' => DB::raw('rate * amount_btc'), 'returns' =>  DB::raw('product + bal_after_7days'), 'save_date' => DB::raw('status_date'),  'week_count' => DB::raw('week_count + 1'), 'status_date' => Carbon::now()]);



        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Premium Plan')->whereRaw('status_date >= SUBDATE( NOW(), INTERVAL 6 DAY)')->where('withdrawn', 'YES')->where('week_count', '<=', 8)->update(['rate' => DB::raw('rate + 0.01488095'), 'returns' =>  DB::raw('rate / 100  * amount_btc + returns')]);
        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Ultimate Plan')->whereRaw('status_date >= SUBDATE( NOW(), INTERVAL 6 DAY)')->where('withdrawn', 'YES')->where('week_count', '<=', 8)->update(['rate' => DB::raw('rate + 0.02232143'), 'returns' =>  DB::raw('rate / 100  * amount_btc + returns')]);

        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Premium Plan')->where('status_date' ,'<=' , Carbon::now()->subDays(7))->where('withdrawn', 'YES')->where('week_count', '<=', 8)->update(['rate' => DB::raw('0.1 + rate1'), 'rate1' => DB::raw('rate'), 'product' => DB::raw('rate * amount_btc + product'), 'returns' =>  DB::raw('product + bal_after_7days'), 'save_date' => DB::raw('status_date'),  'week_count' => DB::raw('week_count + 1'), 'status_date' => Carbon::now()]);
        Transaction::where('confirms_needed', '=', 99)->where('plan', '=', 'Ultimate Plan')->where('status_date' ,'<=' , Carbon::now()->subDays(7))->where('withdrawn', 'YES')->where('week_count', '<=', 8)->update(['rate' => DB::raw('0.15 + rate1'), 'rate1' => DB::raw('rate'), 'product' => DB::raw('rate * amount_btc + product'), 'returns' =>  DB::raw('product + bal_after_7days'), 'save_date' => DB::raw('status_date'),  'week_count' => DB::raw('week_count + 1'), 'status_date' => Carbon::now()]);












        return $this->info('Achieved');


        //User::where('status' , 'PAID')->get();

    }


}
