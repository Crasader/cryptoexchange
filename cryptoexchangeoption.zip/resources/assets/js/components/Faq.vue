<template>
    <div>
        <div class="clearfix"></div>
        <!--======= Breadcrumb Inner Page =======-->
        <section class="iq-bg iq-bg-fixed iq-over-black-70 jarallax iq-breadcrumb text-center iq-font-white" style="background-image: none; background-position: center; background-image: url('images/4.jpg'); background-position: center;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="heading-title iq-mb-25">
                            <h3 class="title text-uppercase iq-font-white iq-tw-6">FAQ</h3>
                        </div>
                        <!--                        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>-->
                    </div>
                </div>
            </div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a :href="`https://cryptotraderslab.com`">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">FAQ</li>
                </ol>
            </nav>
            <div id="jarallax-container-0" style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; overflow: hidden; pointer-events: none; z-index: -100;"><div style="background-position: 50% 50%; background-size: cover; background-repeat: no-repeat; position: fixed; top: 0px; left: 0px; width: 1349px; height: 580.8px; overflow: hidden; pointer-events: none; margin-top: 16.1px; transform: translate3d(0px, 8.3px, 0px);"></div></div></section>

        <!-- start section -->
        <section class="section">
            <div class="grid grid--container">
                <div class="section-heading section-heading--center  col-MB-60">
                    <h2 class="__title">Popular Questions</h2>
                </div>

                <div class="row row--xs-middle">
                    <div class="col col--md-10">
                        <!-- start FAQ -->
                        <div class="faq">
                            <div class="accordion-container">
                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">How do I join ?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                It's quite easy and convenient. Click on the "Register" link, fill in the registration form and then press "CREATE ACCOUNT".
                                            </p>
                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">How can I access my account?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                Click on the login link and enter the required information to access your account.
                                            </p>
                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">What is the minimum investment?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                The minimum investment is $5000.
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">I misplaced my password or can't login to my account?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                Click on the "LOGIN" link, locate the "forgot password" button, enter your email address to receive your login details settings.
                                            </p>
                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">How much profit do we earn with this program?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                The Profit you earn depends on your selected package.
                                            </p>
                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">Can i withdraw my initial capital?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                No you can't. It will be released to you after 8weeks(60days)
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">Are the profits paid weekly or monthly?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                Profits are paid weekly.
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">I don't want to withdraw weekly, can i compound?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                No you can't. There is no option for compounding.
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->

                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">Can I have more than one contract running?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                Yes you can.
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->


                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">How much referral bonus do i get for referring people?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                You get 5% of your referrer investment.
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->


                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">Are the deposits and withdrawals done in BTC or fiat?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                All transactions are done in BTC.But the profits are calculated based on fiat rate and not BTC
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->



                                <!-- start item -->
                                <div class="accordion-item">
                                    <div class="accordion-toggler">
                                        <h4 class="__title h5">What kind of currency do you accept?</h4>

                                        <i class="circled"></i>
                                    </div>

                                    <article>
                                        <div class="__inner">
                                            <p>
                                                At the moment we accept only Bitcoin(BTC).
                                            </p>

                                        </div>
                                    </article>
                                </div>
                                <!-- end item -->



                            </div>
<!--
                            <div class="text&#45;&#45;center">
                                <a class="custom-btn custom-btn&#45;&#45;medium custom-btn&#45;&#45;style-1" href="#">Show more</a>
                            </div>-->
                        </div>
                        <!-- end FAQ -->
                    </div>
                </div>
            </div>
        </section>
        <!-- end section -->
    </div>
</template>