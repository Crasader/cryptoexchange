<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/font-awesome.css')); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <Left></Left>

    <div id="index">
        <div class="mainpanel">

            <div class="contentpanel">

                <ol class="breadcrumb breadcrumb-quirk">
                    <li><a href="<?php echo url('/user/dashboard'); ?>"><i class="fa fa-home mr5"></i> Home</a></li>
                </ol>

                <div class="panel">
                    <div class="panel-heading">
                        <h4 class="panel-title">EDIT USERS</h4>
                    </div>

                    <div class="panel-body">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-danger">
                                <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>

                        
                            <form  role="form" method="POST" action="<?php echo e(route('user.manage-users-post-edit')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($userId); ?>" />
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" class="form-control"  name="full_name" placeholder="Full Name" value="<?php echo e($user->full_name); ?>">
                                <?php if($errors->has('full_name')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('full_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" class="form-control"  name="username" placeholder="Username" value="<?php echo e($user->username); ?>">
                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control"  name="email" placeholder="Email" value="<?php echo e($user->email); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Sponsor Username</label>
                                <input type="text" class="form-control"  name="upline" placeholder="Sponsor Username" value="<?php echo e($user->upline); ?>">
                                <?php if($errors->has('upline')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('upline')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" class="form-control"  name="phone" placeholder="Phone Number" value="<?php echo e($user->phone); ?>">
                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Bitcoin Address</label>
                                <input type="text" class="form-control"  name="bitcoin" placeholder="Bitcoin Wallet" value="<?php echo e($user->bitcoin); ?>">
                                <?php if($errors->has('bitcoin')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('bitcoin')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>City</label>
                                <input type="text" class="form-control"  name="city" placeholder="City" value="<?php echo e($user->city); ?>">
                                <?php if($errors->has('city')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>State</label>
                                <input type="text" class="form-control"  name="state" placeholder="State" value="<?php echo e($user->state); ?>">
                                <?php if($errors->has('state')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('state')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Country</label>
                                <input type="text" class="form-control"  name="country" placeholder="Country" value="<?php echo e($user->country); ?>">
                                <?php if($errors->has('country')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <button class="btn btn-success btn-quirk btn-block">Edit Now</button>
                            </div>
                        </form>

                    </div>
                </div><!-- panel -->


            </div><!-- contentpanel -->
        </div><!-- mainpanel -->

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>