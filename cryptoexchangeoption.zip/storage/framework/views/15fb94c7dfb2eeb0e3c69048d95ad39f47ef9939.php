<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/font-awesome.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/uikit.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/custom.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <Left></Left>
    <div id="index">
        <div class="mainpanel">

            <div class="contentpanel">

                <ol class="breadcrumb breadcrumb-quirk">
                    <li><a href="<?php echo route('user.dashboard'); ?>"><i class="fa fa-home mr5"></i> Home</a></li>
                    <li><a href="">Withdraw Fund</a></li>
                </ol>

                <div class="panel">
                    <div class="panel-heading">
                        <h4 class="panel-title">WITHDRAWAL APPLICATION FORM</h4>
                    </div>

                    <div class="panel-body">

                        <main class="main">
                            <!-- main page starts here -->
                            <div class="breadcrumb">

                                <li class="breadcrumb-item"><span class="uk-badge"> &nbsp; Total Withdrawal: {{ withdrawal.length }} &nbsp; </span></li>
                                <li> &nbsp; <button class="newButton breadcrumb-item uk-button uk-button-primary uk-button-small" href="#newDepositForm" uk-scroll @click="newDepositForm = true">Add New Withdrawal</button></li>
                            </div>

                            <div class="container-fluid">
                                <div class="animated fadeIn">

                                    <!-- new deposit form -->
                                    <div id="newDepositForm" class="col-lg-12 uk-animation-slide-top-medium" v-show="newDepositForm">
                                        <div class="card">
                                            <div class="card-header">
                                                <i class="fa fa-edit"></i>  Fill in the new withdrawal details
                                                <div class="card-actions">
                                                    <a class="pull-right" style="color:#FC0000;"  @click="newDepositForm = false" uk-close></a>
                                                </div>
                                            </div>
                                                               <?php if($bal_after_7days > 0): ?>
                                                                <p style="margin-left:17px;">Your balance is $<?php echo e($bal_after_7days); ?> <br/>It would be available on your 
                                                                next withdrawal</p>
                                                                <?php else: ?>
                                                                    <p style="margin-left:17px;">You have no balance at this time</p>
                                                                <?php endif; ?>
                                            <div class="card-block">
                                                <?php if(count($balance) > 0): ?>
                                                    <?php if($balance->sum('product') > 0): ?>





                                                        
                                                        <form  action="" method="post" @submit.prevent="withdraw()" @keydown="clear($event.target.name)" >
                                                            <div class="box-body">
                                                                <div class="alert alert-success" v-if="submitted">
                                                                    <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                                                                    Your request has been received
                                                                </div>
                                                               
                                                                    <p>Your total balance is $<?php echo e($sum); ?></p>
                                                                 

                                                                <div class="input-group">
                                                                    <span class="input-group-addon">Amount  $</span>
                                                                    <input type="text" class="form-control" id="amount" v-model="withdrawalDetails.amount" placeholder="Withdrawal Amount"  name="amount">
                                                                    <span class="input-group-addon">.00</span>
                                                                </div>
                                                                <span class="help is-danger" style="color: red;">{{ getWithdrawalError('amount') }}</span><br/>
                                                                <span style="color: red;" class="validation" v-show="!validations.amount.is_valid">{{ validations.amount.text }}</span>

                                                                
                                                                <br>

                                                                <input type="hidden" name="total" v-model="withdrawalDetails.total">
                                                                <div class="box-footer">
                                                                    <input type="submit" name="save"  class="btn btn-primary btn-lg" value="Apply">
                                                                </div>
                                                            </div>
                                                            <!-- /.box-body -->
                                                        </form>

<?php endif; ?>



                                                <?php else: ?>
                                                    <?php if(count($referral) > 0): ?>
                                                        <?php if($referral->sum('amount') > 0): ?>



                                                            <form  action="" method="post" @submit.prevent="withdrawReferral()" @keydown="clear($event.target.name)" >
                                                                <div class="box-body">
                                                                    <div class="alert alert-success" v-if="submitted">
                                                                        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                                                                        Your request has been received
                                                                    </div>
                                                                    <p>Your referral balance is <?php echo e($sum); ?></p>
                                                               
                                                                    <div class="input-group">
                                                                        <span class="input-group-addon">Amount  $</span>
                                                                        <input type="text" class="form-control" id="amount" v-model="withdrawalReferralDetails.amount" placeholder="Withdrawal Amount"  name="amount">
                                                                        <span class="input-group-addon">.00</span>
                                                                    </div>
                                                                    <span class="help is-danger" style="color: red;">{{ getWithdrawalReferralError('amount') }}</span><br/>
                                                                    <span style="color: red;" class="validation" v-show="!validations.amount.is_valid">{{ validations.amount.text }}</span>
                                                                    <br>

                                                                    <input type="hidden" name="referral" v-model="withdrawalReferralDetails.referral">
                                                                    <div class="box-footer">
                                                                        <input type="submit" name="save"  class="btn btn-primary btn-lg" value="Apply">
                                                                    </div>
                                                                </div>
                                                                <!-- /.box-body -->
                                                            </form>
                                                        <?php endif; ?>

                                                    <?php else: ?>
                                                        <p>Your account balance is $0</p>
                                                    <?php endif; ?>
                                                <?php endif; ?>


                                                  



                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- new category form -->




                                    <!-- search input -->
                                    <div class="card-block" v-show="!newDepositForm">
                                        <div id="searchForm" class="col-lg-12 uk-animation-slide-top-medium">
                                            <div class="card">
                                                <div class="card-header">
                                                    <input type="text"  class="form-control" placeholder="search withdrawals....">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- search input -->

                                <div class="col-sm-6 col-md-4 uk-animation-slide-bottom-medium"  v-for="withdraw in withdrawal" v-show="!newWithdrawalForm">
                                    <div class="card uk-card uk-card-default uk-card-hover">
                                        <div class="card-block">
                                            <strong class="categoryName"> Amount:</strong> &nbsp;${{ withdraw.amount }}
                                            <hr>
                                            <p> <strong class="categoryDescription">Status:</strong> &nbsp;{{ withdraw.status }}</p>
                                            <p> <strong class="categoryDescription">Application Date:</strong> &nbsp;{{ withdraw.created_at | formatDate }}</p>
                                            <p v-if="withdraw.payment_date == null"> <strong class="categoryDescription">Payment Date:</strong>&nbsp;Not Yet Paid</p>
                                            <p v-else> <strong class="categoryDescription">Payment Date:</strong> &nbsp;{{ withdraw.payment_date | formatDate }}</p>
                                        </div>

                                        <div class="uk-container card-footer">

                                       
                                        </div>
                                    </div>
                                </div>







                            </div>

                        </main>
                            </div>


                    </div>
                </div><!-- panel -->





            </div><!-- contentpanel -->
        </div><!-- mainpanel -->
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/uikit.min.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>