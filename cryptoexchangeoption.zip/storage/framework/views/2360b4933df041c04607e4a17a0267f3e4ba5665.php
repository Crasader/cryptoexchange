<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/font-awesome.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="index">
        <Transactions></Transactions>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>