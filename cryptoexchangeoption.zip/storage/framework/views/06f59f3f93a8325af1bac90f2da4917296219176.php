<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/font-awesome.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <Left></Left>
    <div id="index">
        <section>
            <div class="mainpanel">

                <div class="contentpanel">

                    <ol class="breadcrumb breadcrumb-quirk">
                        <li><a :href="`https://cryptotraderslab.com`"><i class="fa fa-home mr5"></i> Home</a></li>

                    </ol>

                    <div class="panel">
                        <div class="panel-heading">
                            <h4 class="panel-title">CLIENT REFERRALS</h4>
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-danger">
                                    <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="panel-body">
                            <div class="table-responsive">
                                <?php if($referrals->count() > 0): ?>
                                    <table class="table nomargin">
                                        <thead>
                                        <tr>
                                            <th class="text-center">
                                                <label class="ckbox ckbox-primary">
                                                    <input type="checkbox"><span></span>
                                                </label>
                                            </th>
                                            <th>User ID</th>
                                            <th>Sponsor Username</th>
                                            <th>Amount ($)</th>
                                            <th>Withdrawn</th>
                                            <th class="text-center">Edit</th>
                                            <th class="text-center">Delete</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center">
                                                    <label class="ckbox ckbox-primary">
                                                        <input type="checkbox"><span></span>
                                                    </label>
                                                </td>
                                                <td><?php echo e($referral->user_id); ?></td>
                                                <td><?php echo e($referral->sponsor_username); ?></td>
                                                <td><?php echo e($referral->amount); ?></td>
                                                <td><?php echo e($referral->withdraw); ?></td>
                                                <td><a href="<?php echo e(url('/user/admin-referrals') .'/'.$referral->id .'/edit'); ?>"> <span class="label label-warning">Edit Referral</span></a></td>

                                                <td><a onclick="delete_referral('<?php echo e($referral->id); ?>');"  href="<?php echo e(route('admin.delete-referral', ['id' =>$referral->id])); ?>"> <span class="label label-warning">Delete Referral</span></a></td>


                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="alert alert-info">You have no pending referrals</div>
                                <?php endif; ?>
                                <div class="col-md-12 text-center">
                                    <?php echo e($referrals->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>