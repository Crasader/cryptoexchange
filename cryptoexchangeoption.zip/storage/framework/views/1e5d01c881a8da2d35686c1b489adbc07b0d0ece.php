<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/bootstrap.min.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/magnific-popup.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/owl.carousel.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/animate.css'); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/font-awesome.css'); ?>">
    <!-- Ionicons CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/ionicons.min.css'); ?>">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/flaticon.css'); ?>">
    <!-- Shop CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/shop.css'); ?>">
    <!-- REVOLUTION STYLE SHEETS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/settings.css'); ?>">
    <!-- style CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/style.css'); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/responsive.css'); ?>">

    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="app">
  <Home></Home>
    </div>
    <?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/jquery.min.js'); ?>"></script>
    <script src="<?php echo asset('js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo asset('js/popper.min.js'); ?>"></script>
    <script src="<?php echo asset('js/widget.js'); ?>"></script>
    <script src="<?php echo asset('js/all-plugins.js'); ?>"></script>
    <script src="<?php echo asset('js/particles.js'); ?>"></script>
    <script src="<?php echo asset('js/style-customizer.js'); ?>"></script>
    <script src="<?php echo asset('js/jquery.themepunch.tools.min.js'); ?>"></script>
    <script src="<?php echo asset('js/jquery.themepunch.revolution.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.actions.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.carousel.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.kenburn.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.layeranimation.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.migration.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.navigation.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.parallax.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.slideanims.min.js'); ?>"></script>
    <script src="<?php echo asset('js/revolution.extension.video.min.js'); ?>"></script>

    <script src="<?php echo asset('js/custom.js'); ?>"></script>

    <script src="<?php echo asset('js/app.js'); ?>"></script>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>