<footer class="iq-footer-4 white-bg">
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 iq-mtb-20">
                    <div class="iq-copyright iq-mt-10 text-center">Copyright <span id="copyright">2014</span> <a href="<?php echo url('/'); ?>"><span class="iq-font-yellow">Crypto Traders Lab</span> </a> All Rights Reserved </div>
                </div>
            </div>
        </div>
    </div>
</footer>
