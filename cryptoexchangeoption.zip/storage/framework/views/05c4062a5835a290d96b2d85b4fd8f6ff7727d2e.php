<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/font-awesome.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/uikit.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/custom.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <Left></Left>
    <div id="index">
        <div class="mainpanel">

            <div class="contentpanel">

                <ol class="breadcrumb breadcrumb-quirk">
                    <li><a href="<?php echo route('user.dashboard'); ?>"><i class="fa fa-home mr5"></i> Home</a></li>
                    <li><a href="">CHECKOUT</a></li>
                </ol>

                <div class="panel">
                    <div class="panel-heading">
                        <h4 class="panel-title">CHECKOUT</h4>
                    </div>

                    <div class="panel-body">

                        <main class="main">
                            <!-- main page starts here -->

                            <div class="col-sm-5 col-md-12 col-lg-6">
                                <div class="panel panel-danger panel-weather">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Checkout</h4>
                                    </div>
                                    <div class="panel-body inverse">
                                        <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row mb10">
                                            <div class="col-xs-6">
                                                <h2 class="today-day"><strong><a href="<?php echo e($trans->status_url); ?>">Proceed to CoinPayment</a></strong>
                                                </h2>
or copy the url and paste in your browser<br/> <?php echo e($trans->status_url); ?> <br/><br/>

N.B Kindly copy out this address if you do not intend making payment at this time...

                                            </div>
                                            <div class="col-xs-6">
                                            </div>
                                        </div>
                                        <p class="nomargin"></p>
                                        <div class="row mt10">
                                            <div class="col-xs-7">
                                            </div>
                                            <div class="col-xs-5">
                                            </div>
                                        </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div><!-- col-md-12 -->





                        </main>

                    </div>
                </div><!-- panel -->





            </div><!-- contentpanel -->
        </div><!-- mainpanel -->
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/uikit.min.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/custom.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>