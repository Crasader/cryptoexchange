<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/font-awesome.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <Left></Left>
    <div id="index">
        <section>
            <div class="mainpanel">

                <div class="contentpanel">

                    <ol class="breadcrumb breadcrumb-quirk">
                        <li><a :href="`https://cryptotraderslab.com`"><i class="fa fa-home mr5"></i> Home</a></li>

                    </ol>

                    <div class="panel">
                        <div class="panel-heading">
                            <h4 class="panel-title">CLIENT TRANSACTIONS</h4>
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-danger">
                                    <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="panel-body">
                            <div class="table-responsive">
                                <?php if($transactions->count() > 0): ?>
                                <table class="table nomargin">
                                    <thead>
                                    <tr>
                                        <th class="text-center">
                                            <label class="ckbox ckbox-primary">
                                                <input type="checkbox"><span></span>
                                            </label>
                                        </th>
                                        <th>Amount($)</th>
                                        <th>Rate(%)</th>
                                        <th>Transaction ID</th>
                                        <th>Returns</th>
                                        <th>Balance</th>
                                        <th>Plan</th>
                                        <th>Full Name</th>
                                        <th class="text-center">Email</th>
                                        <th class="text-center">BTC Address</th>
                                        <th class="text-center">Week Count</th>
                                        <th class="text-center">Edit</th>
                                        <th class="text-center">Delete</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center">
                                            <label class="ckbox ckbox-primary">
                                                <input type="checkbox"><span></span>
                                            </label>
                                        </td>
                                        <td><?php echo e($transaction->amount_btc); ?></td>
                                        <td><?php echo e($transaction->rate); ?></td>
                                        <td><?php echo e($transaction->txn_id); ?></td>

                                        <td class="text-center"><?php echo e($transaction->returns); ?></td>
                                        <td class="text-center"><?php echo e($transaction->bal_after_7days); ?></td>
                                        <td class="text-center"><?php echo e($transaction->plan); ?></td>
                                        <td><?php echo e($transaction->buyer_name); ?></td>
                                        <td class="text-center"><?php echo e($transaction->buyer_email); ?></td>
                                        <td class="text-center"><?php echo e($transaction->address); ?></td>

                                        <td class="text-center"><?php echo e($transaction->week_count); ?></td>

                                        <td><a href="<?php echo e(url('/user/admin-transactions') .'/'.$transaction->id .'/edit'); ?>"> <span class="label label-warning">Edit Transaction</span></a></td>

                                        <td><a onclick="delete_transaction('<?php echo e($transaction->id); ?>');"  href="<?php echo e(route('admin.delete-transaction', ['id' =>$transaction->id])); ?>"> <span class="label label-warning">Delete Transaction</span></a></td>

                                        <?php if($transaction->status == "PENDING"): ?>
                                            <td> <a href="<?php echo e(url('confirm-payment').'/'.$transaction->id); ?>" class="btn btn-info"><span class="label label-success">ACTIVATE</span></a></td>
                                        <?php else: ?>
                                            <td><button class="btn btn-success"><span class="label label-success"><?php echo e($transaction->status); ?></span></button></td>
                                        <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                    <div class="alert alert-info">You have no pending transaction</div>
                                <?php endif; ?>
                                <div class="col-md-12 text-center">
                                    <?php echo e($transactions->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>