<h3>You have a new contact via the contact form</h3>

<div>
 <?php echo e($bodyMessage); ?>

</div>
<p>Sent via <?php echo e($email); ?></p>