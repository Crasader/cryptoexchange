<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/font-awesome.css')); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <Left></Left>

    <div id="index">
        <div class="mainpanel">

            <div class="contentpanel">

                <ol class="breadcrumb breadcrumb-quirk">
                    <li><a href="<?php echo url('/user/dashboard'); ?>"><i class="fa fa-home mr5"></i> Home</a></li>
                </ol>

                <div class="panel">
                    <div class="panel-heading">
                        <h4 class="panel-title">EDIT TRANSACTION</h4>
                    </div>

                    <div class="panel-body">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-danger">
                                <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>

                        
                        <form  role="form" method="POST" action="<?php echo e(route('user.admin-transactions-post-edit')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($transactionId); ?>" />
                            <div class="form-group">
                                <label>Amount(BTC)</label>
                                <input type="text" class="form-control"  name="amount" placeholder="Amount in BTC" value="<?php echo e($transaction->amount); ?>">
                                <?php if($errors->has('amount')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('amount')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Amount($)</label>
                                <input type="text" class="form-control"  name="amount_btc" placeholder="Amount in Dollars" value="<?php echo e($transaction->amount_btc); ?>">
                                <?php if($errors->has('amount_btc')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('amount_btc')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Rate</label>
                                <input type="text" class="form-control"  name="rate" placeholder="Rate" value="<?php echo e($transaction->rate); ?>">
                                <?php if($errors->has('rate')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('rate')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Product</label>
                                <input type="text" class="form-control"  name="product" placeholder="Product" value="<?php echo e($transaction->product); ?>">
                                <?php if($errors->has('product')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('product')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Profit</label>
                                <input type="text" class="form-control"  name="returns" placeholder="Returns" value="<?php echo e($transaction->returns); ?>">
                                <?php if($errors->has('returns')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('returns')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Balance</label>
                                <input type="text" class="form-control"  name="bal_after_7days" placeholder="Balance After 7days" value="<?php echo e($transaction->bal_after_7days); ?>">
                                <?php if($errors->has('bal_after_7days')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('bal_after_7days')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Plan</label>
                                <input type="text" class="form-control"  name="plan" placeholder="Plan" value="<?php echo e($transaction->plan); ?>">
                                <?php if($errors->has('plan')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('plan')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Date of Activation</label>
                                <input type="date" class="form-control"  name="status_date" value="<?php echo e($transaction->status_date); ?>">
                                <?php if($errors->has('status_date')): ?>
                                    <span class="help-block">
                                        <strong style="color: red"><?php echo e($errors->first('status_date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <button class="btn btn-success btn-quirk btn-block">Edit Now</button>
                            </div>
                        </form>

                    </div>
                </div><!-- panel -->


            </div><!-- contentpanel -->
        </div><!-- mainpanel -->

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>