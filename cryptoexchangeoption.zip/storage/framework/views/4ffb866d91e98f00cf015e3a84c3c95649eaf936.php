<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="a bitcoin trading lab">
    <meta name="author" description="Crypto Traders Lab">
    <meta property="og:url"           content="<?php echo e(url('/')); ?>" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="Crypto Traders Lab" />
    <meta property="og:description"   content="a bitcoin trading lab" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Welcome to Crypto Traders Lab</title>

    <link rel="stylesheet" href="<?php echo asset('css/font-awesome.css'); ?>">

    <link rel="stylesheet" href="<?php echo asset('css/quirk.css'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <link rel="icon" type="image/png" href="<?php echo asset('images/logo-white.png'); ?>" width="140px">
    <script src="<?php echo asset('js/modernizr.js'); ?>"></script>
    <!-- pass php vars to javascript -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'appUrl' => url("/"),
            'siteUser' => auth()->user(),
        ]); ?>
    </script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="../lib/html5shiv/html5shiv.js"></script>
    <script src="../lib/respond/respond.src.js"></script>
    <![endif]-->
</head>

<body class="signwrapper">
<div id="app">
    <Login></Login>
</div>
<script src="<?php echo asset('js/jquery.min.js'); ?>"></script>
<script src="<?php echo asset('js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo asset('js/select2.js'); ?>"></script>
<script src="<?php echo asset('js/app.js'); ?>"></script>
<script>
    $(function() {

        // Select2 Box
        $("select.form-control").select2({ minimumResultsForSearch: Infinity });

    });
</script>



</body></html>
