<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/font-awesome.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/uikit.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/custom.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <Left></Left>
    <div id="index">
        <div class="mainpanel">

            <div class="contentpanel">

                <ol class="breadcrumb breadcrumb-quirk">
                    <li><a href="<?php echo route('user.dashboard'); ?>"><i class="fa fa-home mr5"></i> Home</a></li>
                    <li><a href="">Client Withdrawals</a></li>
                </ol>

                <div class="panel">
                    <div class="panel-heading">
                      
                    </div>

                    <div class="panel-body">
                        <div class="table-responsive">
                            <?php if($withdrawals->count() > 0): ?>
                            <table class="table nomargin">
                                <thead>
                                <tr>
                                    <th class="text-center">
                                        <label class="ckbox ckbox-primary">
                                            <input type="checkbox"><span></span>
                                        </label>
                                    </th>
                                    <th>CLIENT</th>
                                    <th>AMOUNT ($)</th>
                                    <th>STATUS</th>
                                    <th>WITHDRAWAL TYPE</th>
                                    <th>ACTION</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <label class="ckbox ckbox-primary">
                                            <input type="checkbox"><span></span>
                                        </label>
                                    </td>
                                    <td><?php echo e($withdraw->full_name); ?></td>
                                    <td><?php echo e($withdraw->amount); ?></td>
                                    <td><?php echo e($withdraw->status); ?></td>
                                    <?php if($withdraw->type == "total"): ?>
                                        <td><span>Total balance</span></td>
                                    <?php else: ?>
                                        <?php if($withdraw->type == "referral"): ?>
                                            <td><span>Referral balance</span></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($withdraw->status == "NOT PAID" && $withdraw->type == "total"): ?>
                                        <td> <a href="<?php echo e(url('confirm-withdrawal-payment').'/'.$withdraw->id); ?>" class="btn btn-info">PAY NOW</a></td>
                                    <?php else: ?>

                                        <?php if($withdraw->status == "NOT PAID" && $withdraw->type == "referral"): ?>
                                            <td> <a href="<?php echo e(url('confirm-referral-withdrawal-payment').'/'.$withdraw->id); ?>" class="btn btn-info">PAY REFERRAL NOW</a></td>
                                        <?php else: ?>
                                            <td><button class="btn btn-success"><?php echo e($withdraw->status); ?></button></td>

                                        <?php endif; ?>
                                    <?php endif; ?>

                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>


                                </tbody>
                            </table>
                            <?php else: ?>
                                <div class="alert alert-info">You have no pending withdrawals</div>
                            <?php endif; ?>

                            <div class="col-md-12 text-center">
                                <?php echo e($withdrawals->links()); ?>

                            </div>

                        </div><!-- table-responsive -->

                    </div>


                </div>
            </div><!-- panel -->





        </div><!-- contentpanel -->
    </div><!-- mainpanel -->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/uikit.min.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/custom.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>