<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/font-awesome.css'); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/weather-icons.css'); ?>">
    <!-- owl-carousel CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/toggles-full.css'); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/quirk.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/hover.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/ionicons.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/morris.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/uikit.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('css/admin/custom.css'); ?>">
    <!-- Custom CSS -->
    <!-- Style customizer (Remove these two lines please) -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <Left></Left>
    <div id="index">
        <div class="mainpanel">

            <div class="contentpanel">

                <ol class="breadcrumb breadcrumb-quirk">
                    <li><a href="<?php echo url('/'); ?>"><i class="fa fa-home mr5"></i> Home</a></li>
                    <li><a href="<?php echo route('user.fund-users'); ?>">Funding</a></li>
                </ol>

                <div class="panel">
                    <div class="panel-heading">
                        <h4 class="panel-title">FUND USERS</h4>
                    </div>

                    <div class="panel-body">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-danger">
                                <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo route('post-user.fund-users'); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <select name="users" class="form-control">
                                    <option value="0">- Choose a user * -</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->full_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <input name="" class="form-control" value="<?php echo e($user->full_name); ?>" >
                            </div>
                            <?php if($errors->has('users')): ?>
                                <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('users')); ?></strong>
                        </span>
                            <?php endif; ?>
                            <div class="input-group">
                                <span class="input-group-addon">Amount USD</span>
                                <input type="text" class="form-control" id="amount"   name="amount">
                            </div><br/>
                            <?php if($errors->has('amount')): ?>
                                <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('amount')); ?></strong>
                        </span>
                            <?php endif; ?>
                            <div class="input-group">
                                <span class="input-group-addon">Plan</span>
                                <select name="registras_plan" class="form-control">
                                    <option disabled value="">- Choose a package * -</option>
                                    <option>Premium Plan</option>
                                    <option>Ultimate Plan</option>
                                </select>
                            </div><br/>
                            <?php if($errors->has('registras_plan')): ?>
                                <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('registras_plan')); ?></strong>
                        </span>
                            <?php endif; ?>
                            <div class="input-group">
                                <button class="btn btn-success btn-quirk btn-block">Fund Account</button>
                            </div>
                        </form>

                    </div>
                </div><!-- panel -->


            </div><!-- contentpanel -->
        </div><!-- mainpanel -->
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo asset('js/admin/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/modernizr.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/jquery-ui.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/toggles.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/quirk.js'); ?>"></script>
    <script src="<?php echo asset('js/admin/uikit.min.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.fund_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>